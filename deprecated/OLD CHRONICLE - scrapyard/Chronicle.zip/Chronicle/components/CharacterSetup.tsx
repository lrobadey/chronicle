import React, { useState } from 'react';
import { LoadingSpinner, MagicSparklesIcon, WorldLoadingIcon } from './IconComponents';
import ChronicleLogo from './ChronicleLogo';

interface ExperienceSetupProps {
  onExperienceDefined: (prompt: string) => void;
  isLoading: boolean;
}

// Renamed from CharacterSetup, but keeping the filename for minimal changes.
const ExperienceSetup: React.FC<ExperienceSetupProps> = ({ onExperienceDefined, isLoading }) => {
  const [userInput, setUserInput] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim() || isLoading) return;
    await onExperienceDefined(userInput.trim());
  };

  return (
    <div className="container mx-auto max-w-2xl p-8 mt-10 card shadow-glow">
      <div className="text-center mb-8">
        <div className="flex justify-center mb-6">
          <ChronicleLogo size="xl" />
        </div>
        <h2 className="text-3xl font-bold gradient-text app-title">Welcome to Chronicle</h2>
        <p className="mt-2" style={{ color: 'var(--text-muted)' }}>Describe the adventure you'd like to embark on.</p>
      </div>
      
      <div className="p-6" style={{ background: 'var(--bg-secondary)', borderRadius: '12px' }}>
        <form onSubmit={handleSubmit}>
          <label htmlFor="userInput" className="block text-xl text-center font-semibold mb-4" style={{ color: 'var(--text-secondary)' }}>
            What experience would you like?
          </label>
          <textarea
            id="userInput"
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            className="input w-full resize-none"
            placeholder="e.g., A lone detective solving a murder in a cyberpunk city..."
            rows={4}
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading || !userInput.trim()}
            className="btn btn-primary w-full mt-6"
          >
            {isLoading ? (
              <div className="flex items-center space-x-3">
                <WorldLoadingIcon className="w-6 h-6" />
                <span>Creating your world...</span>
              </div>
            ) : (
              <>
                <MagicSparklesIcon className="w-5 h-5 mr-2" />
                Begin Adventure
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default ExperienceSetup;