import React from 'react';

interface ChronicleLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

const ChronicleLogo: React.FC<ChronicleLogoProps> = ({ className = '', size = 'lg' }) => {
  const sizeClasses = {
    sm: 'w-16 h-16',
    md: 'w-24 h-24', 
    lg: 'w-32 h-32',
    xl: 'w-48 h-48'
  };

  return (
    <div className={`${sizeClasses[size]} ${className}`}>
      <img 
        src="/chronicle-logo.png" 
        alt="Chronicle Logo" 
        className="w-full h-full object-contain"
        style={{ filter: 'drop-shadow(0 0 8px var(--aurora))' }}
      />
    </div>
  );
};

export default ChronicleLogo; 