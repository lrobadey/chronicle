import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface ConstellationAnimationProps {
  className?: string;
}

interface TwinklingStar {
  id: number;
  x: number;
  y: number;
  scale: number;
}

const ConstellationAnimation: React.FC<ConstellationAnimationProps> = ({ className }) => {
  const [twinklingStars, setTwinklingStars] = useState<TwinklingStar[]>([]);
  const starIdCounter = useRef(0);

  // Generate a random twinkling star around the screen edges, avoiding the center
  const generateRandomStar = (): TwinklingStar => {
    const containerWidth = 128; // Approximate container width
    const containerHeight = 128; // Approximate container height
    const margin = 20; // Distance from edge
    const centerExclusion = 40; // Size of center area to avoid (where world icon is)
    
    // Randomly choose which edge to place the star
    const edge = Math.floor(Math.random() * 4); // 0: top, 1: right, 2: bottom, 3: left
    
    let x, y;
    let attempts = 0;
    const maxAttempts = 10;
    const centerX = containerWidth / 2;
    const centerY = containerHeight / 2;
    
    do {
      switch (edge) {
        case 0: // Top edge
          x = Math.random() * (containerWidth - 2 * margin) + margin;
          y = margin;
          break;
        case 1: // Right edge
          x = containerWidth - margin;
          y = Math.random() * (containerHeight - 2 * margin) + margin;
          break;
        case 2: // Bottom edge
          x = Math.random() * (containerWidth - 2 * margin) + margin;
          y = containerHeight - margin;
          break;
        case 3: // Left edge
          x = margin;
          y = Math.random() * (containerHeight - 2 * margin) + margin;
          break;
        default:
          x = Math.random() * containerWidth;
          y = Math.random() * containerHeight;
      }
      
      // Check if the position is too close to the center
      const distanceFromCenter = Math.sqrt((x - centerX) ** 2 + (y - centerY) ** 2);
      
      attempts++;
    } while (distanceFromCenter < centerExclusion && attempts < maxAttempts);
    
    // If we couldn't find a good position, force it to the edges
    if (attempts >= maxAttempts) {
      const edgePositions = [
        { x: margin, y: margin }, // Top-left
        { x: containerWidth - margin, y: margin }, // Top-right
        { x: margin, y: containerHeight - margin }, // Bottom-left
        { x: containerWidth - margin, y: containerHeight - margin } // Bottom-right
      ];
      const randomCorner = edgePositions[Math.floor(Math.random() * edgePositions.length)];
      x = randomCorner.x;
      y = randomCorner.y;
    }
    
    return {
      id: starIdCounter.current++,
      x: x - containerWidth / 2, // Center the coordinate system
      y: y - containerHeight / 2,
      scale: 0.5 + Math.random() * 0.5 // Random size between 0.5 and 1
    };
  };

  // Spawn stars at regular intervals
  useEffect(() => {
    const interval = setInterval(() => {
      setTwinklingStars(prevStars => {
        // Remove stars that have been around too long (keep max 10 stars)
        const filteredStars = prevStars.slice(-9);
        return [...filteredStars, generateRandomStar()];
      });
    }, 800); // Spawn a new star every 800ms

    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`relative ${className}`}>
      {/* Twinkling Stars with Framer Motion */}
      <AnimatePresence>
        {twinklingStars.map((star) => (
          <motion.div
            key={`star-${star.id}`}
            className="absolute w-2 h-2 rounded-full"
            style={{
              left: `calc(50% + ${star.x}px)`,
              top: `calc(50% + ${star.y}px)`,
              background: 'var(--aurora)',
              zIndex: 5
            }}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ 
              opacity: [0, 1, 0],
              scale: [0, star.scale * 1.2, 0],
              y: [0, -10, 0]
            }}
            transition={{ 
              duration: 3,
              ease: "easeInOut",
              times: [0, 0.5, 1]
            }}
            exit={{ opacity: 0, scale: 0 }}
          />
        ))}
      </AnimatePresence>

      {/* World Icon with Framer Motion */}
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
        >
          <svg 
            className="w-24 h-24" 
            xmlns="http://www.w3.org/2000/svg" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="var(--aurora)" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
            style={{
              filter: 'drop-shadow(0 0 12px var(--aurora))'
            }}
          >
            <path d="M21 12a9 9 0 1 1-6.219-8.56" />
          </svg>
          <motion.div 
            className="absolute inset-0 flex items-center justify-center"
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 1, repeat: Infinity, ease: "easeInOut" }}
          >
            <div 
              className="w-2 h-2 rounded-full"
              style={{ 
                background: 'var(--aurora)',
                boxShadow: '0 0 8px var(--aurora)'
              }}
            />
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
};

export default ConstellationAnimation; 