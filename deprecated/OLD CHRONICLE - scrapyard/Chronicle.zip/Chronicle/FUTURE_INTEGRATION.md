# Chronicle V2 — Future Integration Plan

**LIVING DOCUMENT FOR AI AGENTS**

This document outlines the complete transformation of Chronicle from its current AI-driven storytelling approach to a sophisticated simulation-based architecture. **AI agents working on this project should use this as a living document - taking notes, updating approaches, and recording progress as they implement features.**

---

## Current State vs. Target Architecture

### Current App (V1)
```
Player Input → AI → GameState Update → UI
```
- Single AI manages everything
- Direct state updates
- Simple arrays and objects
- AI decides all consequences

### Target App (V2)
```
Player Input → Parser → Action → Systems → Patches → Arbiter → GTWG → Projector → PKG → GM → Narrative → UI
```
- Systems calculate deterministic changes
- AI narrates what systems produce
- Complex graph-based world state
- Emergent complexity through system interactions

---

## Core Data Structures

### 1. Ground-Truth World Graph (GTWG)
**Purpose:** The "real" world that exists independently of player knowledge

**Structure:**
- **Entities:** regions, locations, characters, resources, quests, weather, laws, items
- **Relations:** located_in, adjacent_to, trades_with, allied_with, at_war_with, controls, causes, blocks
- **Ownership:** Each mutable field has exactly one owning system
- **Deterministic:** Pure function of (seed, action_history)

**Implementation Notes:**
- Replace current `GameState` interface
- Use graph structure instead of flat arrays
- Implement ownership map to prevent conflicts
- Add validation for entity/relation consistency

### 2. Player-Knowledge Graph (PKG)
**Purpose:** What the player knows vs. what's actually true

**Structure:**
- **Discovered Facts:** Entities and relations the player has seen
- **Rumors:** Information with confidence levels [0,1]
- **Reveal Policy:** Based on player location and actions
- **No Spoilers:** Player never sees full GTWG

**Implementation Notes:**
- Project GTWG based on reveal policy
- Include rumor system with confidence tracking
- Update UI to show only PKG data
- Enable investigation gameplay

### 3. Canon Ledger
**Purpose:** Append-only history of all world changes

**Structure:**
- **Event-sourced:** Complete history of all patches
- **Deterministic IDs:** H(seed, tick, proposer, proposal_hash)
- **Replayable:** Can reconstruct any world state
- **Audit Trail:** For debugging and validation

**Implementation Notes:**
- Replace localStorage with Canon Ledger
- Implement replay functionality
- Add event ID generation
- Enable debugging tools

---

## Kernel System

### 1. SystemSpec Engine
**Purpose:** Parse, validate, and execute system definitions

**Components:**
- **JSON Parser:** Parse SystemSpec definitions
- **Validator:** Check ownership, bounds, dependencies
- **Compiler:** Convert specs to executable reducers
- **Scheduler:** Manage tick rates (per_action, hourly, daily)

**Implementation Notes:**
- Start with simple expression evaluator
- Implement ownership validation
- Add dependency resolution
- Create scheduling system

### 2. Arbiter
**Purpose:** Validate and commit all world changes

**Responsibilities:**
- **Validation Gates:** Check patches before applying
- **Conflict Prevention:** Ensure no ownership conflicts
- **Canon Writing:** Write to Canon Ledger
- **Determinism:** Ensure reproducible results

**Implementation Notes:**
- Implement validation rules
- Add conflict detection
- Create Canon Ledger interface
- Add rollback capability

### 3. Pressure/Patch System
**Purpose:** Normalized communication between systems

**Structure:**
- **Pressure:** {domain, key, loc, value} - normalized inputs
- **Patch:** {op, entity, field, value} - state updates
- **Bounded Expressions:** Only allowed mathematical operations

**Implementation Notes:**
- Create pressure routing system
- Implement patch validation
- Add expression evaluator
- Ensure determinism

---

## Core Reducers (Phase 1)

### 1. WeatherReducer
**Purpose:** Handle weather patterns and effects

**Features:**
- Seasonal patterns (spring, summer, fall, winter)
- Weather states (clear, rain, storm)
- Intensity levels [0-5]
- Effects on travel and economy

**Implementation Notes:**
- Start with simple Markov chain
- Add seasonal transitions
- Implement intensity decay
- Create weather effects on other systems

### 2. TravelReducer
**Purpose:** Handle movement and pathfinding

**Features:**
- Dijkstra pathfinding over routes
- Terrain multipliers
- Weather effects on travel
- Time advancement
- Location discovery

**Implementation Notes:**
- Implement pathfinding algorithm
- Add terrain cost calculations
- Create time advancement system
- Handle location reveals

### 3. EconomyReducer
**Purpose:** Handle supply, demand, and prices

**Features:**
- Resource conservation (stocks/flows)
- Price dynamics with bounds
- Caravan throughput effects
- Weather impact on production

**Implementation Notes:**
- Implement supply/demand logic
- Add price clamping
- Create resource flow system
- Add weather effects

### 4. PoliticsReducer
**Purpose:** Handle unrest, factions, and quests

**Features:**
- Unrest dynamics
- Faction relationships
- Quest generation
- Event triggers

**Implementation Notes:**
- Implement unrest calculation
- Add faction system
- Create quest generation
- Add event triggering

---

## AI Integration

### 1. Action Parser
**Purpose:** Convert player text to structured actions

**Grammar:**
```typescript
type Action = 
  | { type: "travel", to: ID }
  | { type: "talk", to: ID, topic?: string }
  | { type: "inspect", target: ID }
  | { type: "trade", mode: "buy"|"sell", item: ID, qty: number, with: ID }
  | { type: "assist", target: ID, goal: string }
  | { type: "scheme", plan: string }
  | { type: "fight", target: ID }
  | { type: "rest" }
  | { type: "research", topic: string }
```

**Implementation Notes:**
- Start with rule-based parser
- Add LLM classification later
- Validate against PKG
- Suggest valid actions

### 2. GM (Narrative Layer)
**Purpose:** Single LLM for storytelling

**Responsibilities:**
- **Input:** PKG before/after, diffs, legal actions
- **Output:** Prose + suggested actions
- **Constraints:** Only sees PKG, never GTWG
- **Validation:** Must use valid action grammar

**Implementation Notes:**
- Update geminiService.ts for new input/output
- Add PKG projection
- Implement action suggestion
- Add validation

### 3. System Synthesis
**Purpose:** AI proposes new systems when needed

**Process:**
- **Trigger:** Player action needs new mechanic
- **Proposal:** AI generates SystemSpec
- **Validation:** Kernel validates spec
- **Activation:** System becomes active

**Implementation Notes:**
- Add system proposal logic
- Implement spec validation
- Create activation system
- Add retirement logic

---

## Implementation Phases

### Phase 1: Foundation (Week 1)
**Goals:**
- [ ] GTWG data structure
- [ ] Basic reducers (Weather, Travel)
- [ ] Simple validation
- [ ] Canon Ledger
- [ ] Basic PKG projection

**Success Criteria:**
- Weather affects travel
- Player movement works
- State is deterministic
- Can replay from seed

### Phase 2: Gameplay (Week 2)
**Goals:**
- [ ] Economy and Politics reducers
- [ ] Action parser
- [ ] GM integration
- [ ] Advanced PKG projection
- [ ] UI updates for PKG

**Success Criteria:**
- Player actions affect economy
- Quests emerge from unrest
- AI narrates system changes
- UI shows only player knowledge

### Phase 3: Organic Growth
**Goals:**
- [ ] System synthesis
- [ ] Advanced validation
- [ ] Performance optimization
- [ ] Complex system interactions

**Success Criteria:**
- AI can propose new systems
- Complex emergent behavior
- Good performance
- Robust error handling

---

## File Structure Changes

### New Files to Create
```
src/
├── kernel/
│   ├── SystemSpec.ts
│   ├── Arbiter.ts
│   ├── Validator.ts
│   └── Scheduler.ts
├── reducers/
│   ├── WeatherReducer.ts
│   ├── TravelReducer.ts
│   ├── EconomyReducer.ts
│   └── PoliticsReducer.ts
├── data/
│   ├── GTWG.ts
│   ├── PKG.ts
│   └── CanonLedger.ts
├── ai/
│   ├── ActionParser.ts
│   ├── GMService.ts
│   └── SystemSynthesis.ts
└── utils/
    ├── ExpressionEvaluator.ts
    └── Pathfinding.ts
```

### Files to Modify
- `App.tsx` - Update data flow
- `types.ts` - Add new interfaces
- `services/geminiService.ts` - Update for GM role
- `components/` - Update to use PKG instead of full state

---

## Migration Strategy

### Step 1: Parallel Implementation
- Keep current app working
- Build new system alongside
- Test new components independently
- Ensure no breaking changes

### Step 2: Gradual Migration
- Start with simple reducers
- Migrate one component at a time
- Test thoroughly at each step
- Maintain backward compatibility

### Step 3: Full Switch
- Replace old data flow
- Update all components
- Remove old code
- Performance optimization

---

## Testing Strategy

### Unit Tests
- [ ] Reducer logic
- [ ] Validation rules
- [ ] Expression evaluation
- [ ] Pathfinding

### Integration Tests
- [ ] System interactions
- [ ] AI integration
- [ ] Data flow
- [ ] Performance

### Property-Based Tests
- [ ] Determinism
- [ ] No orphan entities
- [ ] Conservation laws
- [ ] Bounds checking

---

## Success Metrics

### Technical Metrics
- **Coherence Rate:** % turns with zero validation failures
- **Performance:** <10ms per reducer, <2s for GM
- **Determinism:** Same seed + actions = same result
- **Memory:** Efficient GTWG/PKG storage

### Gameplay Metrics
- **Emergence:** Complex stories from simple rules
- **Agency:** Player actions have meaningful consequences
- **Learnability:** Players can understand systems
- **Engagement:** Players want to explore and experiment

---

## Risks and Mitigations

### Technical Risks
- **Complexity:** Start simple, add incrementally
- **Performance:** Profile early, optimize bottlenecks
- **Debugging:** Add comprehensive logging
- **Memory:** Implement efficient data structures

### Design Risks
- **Over-engineering:** Focus on core features first
- **AI Integration:** Keep GM simple initially
- **User Experience:** Test with real players
- **Emergence:** Validate that systems create interesting behavior

---

## Notes for AI Agents

**This is a living document. As you implement features:**

1. **Update Progress:** Mark completed items with [x]
2. **Add Discoveries:** Document new approaches or insights
3. **Record Issues:** Note problems and solutions
4. **Suggest Improvements:** Propose better approaches
5. **Update Architecture:** Refine the design as needed

**CRITICAL IMPLEMENTATION GUIDELINES:**

### 🚨 EXTREME CAUTION REQUIRED
- **This is a MASSIVE refactor** - treat every change as potentially breaking
- **Reason extensively** before making any changes
- **Test thoroughly** after every modification
- **Keep the current app working** at all times

### 📋 BEFORE MAKING ANY CHANGES
1. **Understand the current codebase** completely
2. **Plan the change** in detail
3. **Consider all side effects** and dependencies
4. **Have a rollback plan** ready
5. **Test the change** in isolation first

### 🔄 INTEGRATION APPROACH
- **Integrate systems INTO existing architecture** - don't replace it
- **Add new features alongside** current features
- **Maintain backward compatibility** at all times
- **Gradual migration** - one component at a time
- **Parallel development** - build new systems separately first

### 🧪 TESTING REQUIREMENTS
- **Unit test** every new component
- **Integration test** with existing systems
- **End-to-end test** the full user flow
- **Performance test** to ensure no regressions
- **Manual testing** of all user-facing features

### 📊 PROGRESS TRACKING
- **Document every change** made
- **Record any issues** encountered
- **Note unexpected side effects**
- **Update this document** with learnings
- **Track performance metrics** before/after

**Remember:**
- Start simple, add complexity incrementally
- Test thoroughly at each step
- Maintain determinism and consistency
- Focus on emergent behavior
- Keep the player experience smooth
- **The current app works well - don't break it!**

---

## Next Steps

1. **Start with GTWG data structure**
2. **Implement basic WeatherReducer**
3. **Add simple validation**
4. **Test determinism**
5. **Iterate and expand**

**The goal is to transform Chronicle from a smart chatbot into a living simulation with emergent storytelling.** 