import { WeatherState, WeatherType, ClimateZone } from '../types';

// Weather transition probabilities (Markov chain)
const WEATHER_TRANSITIONS: Record<WeatherType, Record<WeatherType, number>> = {
  clear: {
    clear: 0.7,
    rain: 0.2,
    fog: 0.1,
    storm: 0.0,
    snow: 0.0
  },
  rain: {
    clear: 0.3,
    rain: 0.5,
    storm: 0.2,
    fog: 0.0,
    snow: 0.0
  },
  storm: {
    clear: 0.1,
    rain: 0.6,
    storm: 0.3,
    fog: 0.0,
    snow: 0.0
  },
  fog: {
    clear: 0.4,
    rain: 0.3,
    fog: 0.3,
    storm: 0.0,
    snow: 0.0
  },
  snow: {
    clear: 0.2,
    rain: 0.1,
    fog: 0.1,
    storm: 0.0,
    snow: 0.6
  }
};

// Temperature ranges for each weather type (Celsius)
const TEMPERATURE_RANGES: Record<WeatherType, { min: number; max: number }> = {
  clear: { min: 15, max: 25 },
  rain: { min: 8, max: 18 },
  storm: { min: 5, max: 15 },
  fog: { min: 10, max: 20 },
  snow: { min: -5, max: 5 }
};

// Wind speed ranges for each weather type (km/h)
const WIND_SPEED_RANGES: Record<WeatherType, { min: number; max: number }> = {
  clear: { min: 0, max: 15 },
  rain: { min: 5, max: 25 },
  storm: { min: 20, max: 50 },
  fog: { min: 0, max: 10 },
  snow: { min: 0, max: 20 }
};

// Climate-based temperature ranges (Celsius)
const CLIMATE_TEMPERATURES: Record<ClimateZone, {
  summer: { day: number; night: number };
  winter: { day: number; night: number };
}> = {
  tropical: {
    summer: { day: 32, night: 23 },
    winter: { day: 28, night: 20 }
  },
  desert: {
    summer: { day: 40, night: 20 },
    winter: { day: 25, night: 10 }
  },
  temperate: {
    summer: { day: 25, night: 15 },
    winter: { day: 5, night: -5 }
  },
  cold: {
    summer: { day: 15, night: 5 },
    winter: { day: -10, night: -20 }
  },
  arctic: {
    summer: { day: 10, night: 0 },
    winter: { day: -25, night: -35 }
  },
  mediterranean: {
    summer: { day: 30, night: 20 },
    winter: { day: 15, night: 5 }
  },
  high_altitude: {
    summer: { day: 15, night: 5 },
    winter: { day: -5, night: -15 }
  }
};

/**
 * Parses world time to extract season and time of day
 */
function parseWorldTime(worldTime: string): { season: 'summer' | 'winter'; timeOfDay: 'day' | 'night' } {
  try {
    const date = new Date(worldTime);
    const month = date.getMonth(); // 0-11
    const hour = date.getHours(); // 0-23
    
    // Determine season (simplified: Dec-Feb = winter, Jun-Aug = summer, others = summer for simplicity)
    const season = (month >= 11 || month <= 1) ? 'winter' : 'summer';
    
    // Determine time of day (6-18 = day, others = night)
    const timeOfDay = (hour >= 6 && hour <= 18) ? 'day' : 'night';
    
    return { season, timeOfDay };
  } catch (error) {
    // Fallback to temperate defaults if parsing fails
    return { season: 'summer', timeOfDay: 'day' };
  }
}

/**
 * Calculates base temperature based on climate, season, and time of day
 */
function getClimateBaseTemperature(climateZone: ClimateZone, worldTime: string): number {
  const { season, timeOfDay } = parseWorldTime(worldTime);
  const climateData = CLIMATE_TEMPERATURES[climateZone];
  
  if (!climateData) {
    // Fallback to temperate if climate zone is invalid
    return CLIMATE_TEMPERATURES.temperate[season][timeOfDay];
  }
  
  return climateData[season][timeOfDay];
}

/**
 * Gets weather temperature modifier
 */
function getWeatherTemperatureModifier(weatherType: WeatherType): number {
  switch (weatherType) {
    case 'clear': return 0; // No modifier
    case 'rain': return -2; // Cooling effect
    case 'storm': return -5; // Significant cooling
    case 'fog': return -1; // Slight cooling
    case 'snow': return -10; // Major cooling
    default: return 0;
  }
}

/**
 * Simple deterministic random number generator
 * Uses a seed to ensure reproducible results
 */
function seededRandom(seed: string): () => number {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    const char = seed.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit integer
  }
  
  let state = Math.abs(hash);
  
  return () => {
    state = (state * 9301 + 49297) % 233280;
    return state / 233280;
  };
}

/**
 * Selects the next weather type based on current weather and random seed
 */
function getNextWeatherType(currentType: WeatherType, seed: string): WeatherType {
  const random = seededRandom(seed);
  const transitions = WEATHER_TRANSITIONS[currentType];
  const rand = random();
  
  let cumulative = 0;
  for (const [weatherType, probability] of Object.entries(transitions)) {
    cumulative += probability;
    if (rand <= cumulative) {
      return weatherType as WeatherType;
    }
  }
  
  return currentType; // Fallback
}

/**
 * Generates a new weather state based on current weather and time
 */
export function updateWeather(
  currentWeather: WeatherState | null,
  worldTime: string,
  seed: string = 'default'
): WeatherState {
  const now = new Date().toISOString();
  
  // If no current weather, start with clear weather
  if (!currentWeather) {
    return {
      type: 'clear',
      intensity: 2,
      temperature: 20,
      windSpeed: 5,
      lastUpdate: now,
      climateZone: 'temperate' // Default climate zone
    };
  }
  
  // Create a seed based on world time for deterministic changes
  const timeSeed = `${seed}-${worldTime}`;
  const random = seededRandom(timeSeed);
  
  // Determine if weather should change (30% chance per hour)
  const shouldChange = random() < 0.3;
  
  let newType = currentWeather.type;
  if (shouldChange) {
    newType = getNextWeatherType(currentWeather.type, timeSeed);
  }
  
  // Update intensity (gradual changes)
  let newIntensity = currentWeather.intensity;
  if (newType !== currentWeather.type) {
    // Reset intensity when weather type changes
    newIntensity = Math.floor(random() * 3) + 1; // 1-3
  } else {
    // Gradual intensity changes
    const intensityChange = (random() - 0.5) * 2; // -1 to 1
    newIntensity = Math.max(0, Math.min(5, currentWeather.intensity + intensityChange));
  }
  
  // Calculate climate-aware temperature
  const climateZone = currentWeather.climateZone || 'temperate'; // Default to temperate for backward compatibility
  const baseTemperature = getClimateBaseTemperature(climateZone, worldTime);
  const weatherModifier = getWeatherTemperatureModifier(newType);
  const newTemperature = baseTemperature + weatherModifier;
  
  // Update wind speed based on weather type
  const windRange = WIND_SPEED_RANGES[newType];
  const newWindSpeed = windRange.min + (random() * (windRange.max - windRange.min));
  
  return {
    type: newType,
    intensity: Math.round(newIntensity),
    temperature: Math.round(newTemperature * 10) / 10, // Round to 1 decimal
    windSpeed: Math.round(newWindSpeed),
    lastUpdate: now,
    climateZone: climateZone // Preserve climate zone
  };
}

/**
 * Gets weather description for AI prompts
 */
export function getWeatherDescription(weather: WeatherState): string {
  const intensityDescriptions = {
    0: 'very light',
    1: 'light',
    2: 'moderate',
    3: 'heavy',
    4: 'very heavy',
    5: 'extreme'
  };
  
  const intensityDesc = intensityDescriptions[weather.intensity as keyof typeof intensityDescriptions] || 'moderate';
  
  return `${intensityDesc} ${weather.type} with ${weather.temperature}°C temperature and ${weather.windSpeed} km/h winds`;
}

/**
 * Checks if weather affects travel speed
 */
export function getWeatherTravelMultiplier(weather: WeatherState): number {
  switch (weather.type) {
    case 'clear':
      return 1.0;
    case 'rain':
      return weather.intensity <= 2 ? 0.9 : 0.8;
    case 'storm':
      return weather.intensity <= 3 ? 0.7 : 0.5;
    case 'fog':
      return weather.intensity <= 2 ? 0.8 : 0.6;
    case 'snow':
      return weather.intensity <= 2 ? 0.6 : 0.4;
    default:
      return 1.0;
  }
} 