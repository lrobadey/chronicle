export enum GamePhase {
  SETUP,
  PLAYING,
}

export enum MessageSender {
  Player = 'PLAYER',
  GM = 'GM',
  SYSTEM = 'SYSTEM'
}

export interface GameMessage {
  id: string;
  sender: MessageSender;
  text: string;
  isLoading?: boolean;
  timestamp?: string;
}

export type VisitState = 'unvisited' | 'visited' | 'current' | 'important';

export interface MapFeature {
  id: string;
  type: 'building' | 'road' | 'terrain' | 'player';
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
  visitState?: VisitState;
}

export interface MapData {
  playerX: number;
  playerY: number;
  gridSize: number;
  features: MapFeature[];
}

// Weather system types
export type WeatherType = 'clear' | 'rain' | 'storm' | 'fog' | 'snow';

export type ClimateZone = 'tropical' | 'desert' | 'temperate' | 'cold' | 'arctic' | 'mediterranean' | 'high_altitude';

export interface WeatherState {
  type: WeatherType;
  intensity: number; // 0-5 scale
  temperature: number; // Celsius
  windSpeed: number; // km/h
  lastUpdate: string; // ISO timestamp
  climateZone?: ClimateZone; // Optional for backward compatibility
}

export interface GameState {
  worldTime: string;
  worldState: string;
  regions: string[];
  locations: string[];
  people: string[];
  quests: string[];
  motives: string[];
  lore: string[];
  mapData: MapData;
  weather?: WeatherState; // Optional for backward compatibility
  climateZone?: ClimateZone; // Optional for backward compatibility
}

export interface AIChanges {
  worldTime?: string;
  worldState?: string;
  regions?: { add?: string[], remove?: string[] };
  locations?: { add?: string[], remove?: string[] };
  people?: { add?: string[], remove?: string[] };
  quests?: { add?: string[], remove?: string[] };
  motives?: { add?: string[], remove?: string[] };
  lore?: { add?: string[], remove?: string[] };
  mapData?: {
    playerX?: number;
    playerY?: number;
    features?: { add?: MapFeature[], remove?: string[], update?: MapFeature[] };
  };
  weather?: WeatherState; // Optional for backward compatibility
  climateZone?: ClimateZone; // Optional for backward compatibility
}

export interface AIResponse {
  narrative: string;
  changes: AIChanges;
}